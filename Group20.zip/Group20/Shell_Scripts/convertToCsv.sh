sed 's/ \{1,\}/,/g' log_update.txt>>new_req.csv
> log_update.txt
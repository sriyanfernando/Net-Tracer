
touch Stored_Reports/new
java Plugin > new
mv new "Report_"`date +"%d-%m-%Y"`

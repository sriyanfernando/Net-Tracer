

1. Copy all the source code files to the location you want to      keep the plugin(Follow the instructions provided in LibreNMS official site to create the folder hierarchy required)

2. Compile the Java code by running the command "javac Plugin.java"

3. Follow the procedure in the LibreNMS official site in order to add the plugin.

4. Enjoy!!